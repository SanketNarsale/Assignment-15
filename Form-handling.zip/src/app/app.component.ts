import { Component } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { BsDropdownConfig } from 'ngx-bootstrap/dropdown';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
  providers: [FormBuilder,{ provide: BsDropdownConfig, useValue: { isAnimated: true, autoClose: true } }]
})
export class AppComponent {
  title = 'Forms';
  selected?: string;
  states: string[] = [
    'Maharashtra',
    'Gujrat',
    'Uttarpradesh',
    ];
  constructor (public fobj: FormBuilder)
  {

  }

  MarvellousForm = this.fobj.group({
     
     firstname : ['omkar',[Validators.required,Validators.minLength(5),Validators.pattern('[a-zA-Z ]*')]],
     lastName : ['',Validators.required],
     email :['',[Validators.required]],
     phone :['',[Validators.required,Validators.minLength(10),Validators.maxLength(10),Validators.pattern('[0-9]*')]],
     address :['',[Validators.required]],
     code :['',[Validators.required]],
     city :['',[Validators.required]],
     state :['',[Validators.required]],


  });
  


}
